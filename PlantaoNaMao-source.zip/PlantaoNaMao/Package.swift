// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "PlantaoNaMao",
    platforms: [.iOS(.v17)],
    products: [.library(name: "PlantaoNaMao", targets: ["PlantaoNaMao"])],
    targets: [.target(name: "PlantaoNaMao")]
)
