# Diagnóstico do IPA fornecido

## Observações verificadas

- Bundle: `com.bivis.plantao`
- Nome exibido: `Shift Calendar`
- Versão: `1.6.3 (82)`
- Plataforma mínima: iOS 17
- Arquitetura: Mach-O arm64
- Implementação nativa com Swift, SwiftUI, UIKit e Combine
- Frameworks de sistema observados: Calendar/Charts, EventKit, MapKit, WidgetKit, StoreKit, WebKit, AVFoundation e LocalAuthentication
- Componentes de terceiros observados: Firebase Auth/Firestore/Messaging, Google Sign-In, Facebook SDK, RevenueCat e RRuleSwift
- Recursos de produto indicados pelas strings: escalas recorrentes, escalas de dias/horas, locais de trabalho, mapa, horas remuneradas, notificações, backup, autenticação e assinatura Pro

## Limite da reconstrução

O protótipo em `Sources/PlantaoNaMao/PlantaoNaMao.swift` é uma implementação limpa. Ele não modifica o IPA, não remove verificações de assinatura e não reutiliza código, chaves ou assets do aplicativo analisado.
