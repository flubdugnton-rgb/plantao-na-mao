import SwiftUI

@main
struct PlantaoNaMaoApp: App {
    @StateObject private var store = ShiftStore()

    var body: some Scene {
        WindowGroup { ContentView().environmentObject(store) }
    }
}

struct Shift: Identifiable, Codable, Equatable {
    var id = UUID()
    var date: Date
    var title: String
    var location: String
    var start: Date
    var end: Date
    var color: ShiftColor = .mint
    var notes = ""

    var duration: String {
        let hours = Calendar.current.dateComponents([.hour, .minute], from: start, to: end)
        return "\(hours.hour ?? 0)h \(hours.minute ?? 0)min"
    }
}

enum ShiftColor: String, Codable, CaseIterable, Identifiable {
    case mint, sage, emerald, lime
    var id: String { rawValue }
    var value: Color {
        switch self { case .mint: .mint; case .sage: Color(red: 0.38, green: 0.68, blue: 0.48); case .emerald: .green; case .lime: Color(red: 0.65, green: 0.82, blue: 0.32) }
    }
}

final class ShiftStore: ObservableObject {
    @Published var shifts: [Shift] = [] { didSet { save() } }
    private let key = "plantao-na-mao.shifts"
    init() { load() }
    func add(_ shift: Shift) { shifts.append(shift); shifts.sort { $0.date < $1.date } }
    func remove(_ shift: Shift) { shifts.removeAll { $0.id == shift.id } }
    func shifts(on day: Date) -> [Shift] { shifts.filter { Calendar.current.isDate($0.date, inSameDayAs: day) } }
    private func save() { guard let data = try? JSONEncoder().encode(shifts) else { return }; UserDefaults.standard.set(data, forKey: key) }
    private func load() { guard let data = UserDefaults.standard.data(forKey: key), let value = try? JSONDecoder().decode([Shift].self, from: data) else { return }; shifts = value }
}

struct ContentView: View {
    @EnvironmentObject private var store: ShiftStore
    @State private var selectedDate = Date()
    @State private var showingEditor = false
    private let calendar = Calendar.current

    var body: some View {
        TabView {
            NavigationStack {
                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        header
                        monthGrid
                        dayList
                    }.padding()
                }
                .background(Color(.systemGroupedBackground))
                .navigationTitle("Plantão na Mão")
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Button { showingEditor = true } label: { Image(systemName: "plus") } } }
                .sheet(isPresented: $showingEditor) { ShiftEditor(date: selectedDate) }
            }.tabItem { Label("Escalas", systemImage: "calendar") }

            NavigationStack { LocationsView() }.tabItem { Label("Locais", systemImage: "mappin.and.ellipse") }
            NavigationStack { SettingsView() }.tabItem { Label("Ajustes", systemImage: "gearshape") }
        }.tint(.green)
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(selectedDate.formatted(.dateTime.weekday(.wide).day().month(.wide))).font(.title2.bold())
            Text("Organize seus próximos plantões").foregroundStyle(.secondary)
        }
    }

    private var monthGrid: some View {
        let days = calendar.range(of: .day, in: .month, for: selectedDate).map(Array.init) ?? []
        let first = calendar.date(from: calendar.dateComponents([.year, .month], from: selectedDate)) ?? selectedDate
        let offset = calendar.component(.weekday, from: first) - 1
        return VStack(spacing: 8) {
            HStack { ForEach(["D","S","T","Q","Q","S","S"], id: \.self) { Text($0).font(.caption.bold()).frame(maxWidth: .infinity).foregroundStyle(.secondary) } }
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 7), spacing: 8) {
                ForEach(0..<(offset + days.count), id: \.self) { index in
                    if index < offset { Color.clear.frame(height: 34) } else {
                        let day = days[index - offset]
                        let date = calendar.date(byAdding: .day, value: day - 1, to: first)!
                        Button { selectedDate = date } label: {
                            VStack(spacing: 3) { Text("\(day)").font(.subheadline.weight(calendar.isDate(date, inSameDayAs: selectedDate) ? .bold : .regular)); Circle().fill(store.shifts(on: date).isEmpty ? .clear : .green).frame(width: 5, height: 5) }
                                .frame(maxWidth: .infinity).frame(height: 34).background(calendar.isDate(date, inSameDayAs: selectedDate) ? Color.green.opacity(0.18) : .clear).clipShape(RoundedRectangle(cornerRadius: 8))
                        }.buttonStyle(.plain)
                    }
                }
            }
        }.padding().background(.background).clipShape(RoundedRectangle(cornerRadius: 18))
    }

    private var dayList: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Plantões do dia").font(.headline)
            let items = store.shifts(on: selectedDate)
            if items.isEmpty { ContentUnavailableView("Nenhum plantão", systemImage: "calendar.badge.plus", description: Text("Toque em + para adicionar uma escala.")) }
            ForEach(items) { shift in ShiftRow(shift: shift) }
        }
    }
}

struct ShiftRow: View {
    let shift: Shift
    var body: some View {
        HStack(spacing: 12) {
            RoundedRectangle(cornerRadius: 4).fill(shift.color.value).frame(width: 6)
            VStack(alignment: .leading, spacing: 4) { Text(shift.title).font(.headline); Text(shift.location).foregroundStyle(.secondary); Text("\(shift.start.formatted(date: .omitted, time: .shortened)) – \(shift.end.formatted(date: .omitted, time: .shortened)) · \(shift.duration)").font(.caption).foregroundStyle(.secondary) }
            Spacer(); Image(systemName: "chevron.right").foregroundStyle(.tertiary)
        }.padding().background(.background).clipShape(RoundedRectangle(cornerRadius: 14))
    }
}

struct ShiftEditor: View {
    @EnvironmentObject private var store: ShiftStore
    @Environment(\.dismiss) private var dismiss
    @State private var title = "Plantão"
    @State private var location = ""
    @State private var date: Date
    @State private var start = Calendar.current.date(bySettingHour: 7, minute: 0, second: 0, of: .now)!
    @State private var end = Calendar.current.date(bySettingHour: 19, minute: 0, second: 0, of: .now)!
    @State private var color: ShiftColor = .mint
    init(date: Date) { _date = State(initialValue: date) }
    var body: some View {
        NavigationStack { Form {
            Section("Detalhes") { TextField("Nome", text: $title); TextField("Local de trabalho", text: $location); DatePicker("Data", selection: $date, displayedComponents: .date) }
            Section("Horário") { DatePicker("Início", selection: $start, displayedComponents: .hourAndMinute); DatePicker("Fim", selection: $end, displayedComponents: .hourAndMinute) }
            Section("Cor") { Picker("Cor", selection: $color) { ForEach(ShiftColor.allCases) { Text($0.rawValue.capitalized).tag($0) } }.pickerStyle(.segmented) }
        }.navigationTitle("Novo plantão").toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }; ToolbarItem(placement: .confirmationAction) { Button("Salvar") { store.add(Shift(date: date, title: title, location: location.isEmpty ? "Sem local" : location, start: start, end: end, color: color)); dismiss() } } } }
    }
}

struct LocationsView: View { var body: some View { ContentUnavailableView("Locais de trabalho", systemImage: "mappin.and.ellipse", description: Text("Adicione hospitais, clínicas e outros locais ao criar seus plantões.")) } }
struct SettingsView: View { var body: some View { List { Section("Plantão na Mão") { Label("Todos os recursos disponíveis", systemImage: "checkmark.seal.fill").foregroundStyle(.green); Label("Dados armazenados neste dispositivo", systemImage: "lock.fill") }; Section("Sobre") { Text("Versão 1.0"); Text("Uma agenda independente para organizar escalas.") } }.navigationTitle("Ajustes") } }
