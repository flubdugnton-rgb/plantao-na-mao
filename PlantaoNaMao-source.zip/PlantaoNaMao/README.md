# Plantão na Mão

Protótipo independente em SwiftUI para iOS 17+, inspirado na categoria de aplicativos de agenda de plantões. Ele usa verde-claro, permite cadastrar escalas e salva os dados localmente no dispositivo.

## Abrir no Xcode

Abra a pasta no Xcode e crie um app iOS SwiftUI apontando o target para `Sources/PlantaoNaMao/PlantaoNaMao.swift`, ou adicione os arquivos a um projeto iOS existente. O pacote não depende de Firebase, RevenueCat ou StoreKit.

## Escopo

Este projeto é uma implementação limpa: não contém código, chaves, assets ou mecanismos de desbloqueio do IPA analisado.

## Google Sign-In

O cliente OAuth público informado para o app está em `GoogleSignInConfig.swift`. No Google Cloud/Firebase, cadastre o cliente como **iOS** com o Bundle ID `com.plantaonamao.app`. A integração visual pode usar o SDK oficial `GoogleSignIn-iOS`; nenhum client secret deve ser incluído no app.
