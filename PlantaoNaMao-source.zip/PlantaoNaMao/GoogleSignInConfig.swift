import Foundation

/// Public OAuth configuration for the iOS client.
/// The client ID is not a client secret; keep server credentials out of the app.
enum GoogleSignInConfig {
    static let clientID = "240965240632-fd5s8htiparn8kk84rpctc1ggrfrur2g.apps.googleusercontent.com"
    static let bundleID = "com.plantaonamao.app"
    static let reversedClientID = "com.googleusercontent.apps.240965240632-fd5s8htiparn8kk84rpctc1ggrfrur2g"
}
